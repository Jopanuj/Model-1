# 🤖 NeuralPulse — AI & Tech Blog
### Fully Automated Blog with Groq + Gemini AI

---

## 📁 Your Files

```
ai-tech-blog/
├── index.html          ← Your main blog website
├── generate.html       ← AI article generator tool (private, don't share)
├── articles/
│   └── articles.json   ← Where generated articles are stored
└── .github/
    └── workflows/
        └── deploy.yml  ← Auto-deploys to GitHub Pages
```

---

## 🚀 STEP 1: Upload to GitHub (5 minutes)

1. Go to **github.com** → Sign in (or create free account)
2. Click **"New repository"** (green button)
3. Name it: `neuralpulse` (or any name you like)
4. Set to **Public**
5. Click **"Create repository"**
6. Click **"uploading an existing file"**
7. Drag and drop ALL your files into the uploader
8. Click **"Commit changes"**

---

## 🌐 STEP 2: Enable GitHub Pages (2 minutes)

1. Go to your repo → **Settings** tab
2. Click **"Pages"** in the left sidebar
3. Under **Source**, select **"GitHub Actions"**
4. Wait 2-3 minutes
5. Your blog is live at: `https://YOUR-USERNAME.github.io/neuralpulse`

---

## 🔑 STEP 3: Get Your Free API Keys

### Groq API Key (Free)
1. Go to **console.groq.com**
2. Sign up for free
3. Click "API Keys" → "Create API Key"
4. Copy the key starting with `gsk_...`

### Gemini API Key (Free)  
1. Go to **aistudio.google.com**
2. Sign in with Google
3. Click "Get API Key" → "Create API key"
4. Copy the key starting with `AIza...`

---

## 🤖 STEP 4: Generate Articles

1. Open `generate.html` on your computer (just double-click it — no server needed!)
2. Paste your Groq or Gemini API key
3. Type a topic or leave blank (AI will pick one)
4. Click **"Generate Article"**
5. Click **"Copy JSON"**
6. Go to your GitHub repo → `articles/articles.json`
7. Click the pencil ✏️ icon to edit
8. Replace `[]` with `[PASTE YOUR JSON HERE]`
9. Click **"Commit changes"**
10. Wait 2 minutes → your article is live! 🎉

---

## ⚡ STEP 5: Set Up Auto-Schedule

Use the **Auto-Schedule** button in `generate.html`:
- Set interval (e.g. every 8 hours)
- Click "Start Auto-Schedule"
- The generator will produce new articles automatically
- Copy the JSON and commit to GitHub each time

**Or use GitHub Actions** (fully automatic, no manual work):
- See `advanced-automation.md` for Python script setup

---

## 💰 STEP 6: Add Google AdSense

1. Go to **adsense.google.com** → Sign up
2. Add your website URL
3. Wait for Google approval (1-14 days)
4. Once approved, get your Publisher ID (looks like `ca-pub-1234567890`)
5. In `index.html`, find this comment:
   ```html
   <!-- <script async src="https://pagead2.googlesyndication.com/...
   ```
6. Uncomment it and replace `YOUR_ADSENSE_ID` with your Publisher ID
7. Commit to GitHub → ads go live automatically!

---

## 🔗 STEP 7: Affiliate Links (Earn Commission)

Sign up for these FREE affiliate programs:

| Program | Commission | Link |
|---------|-----------|------|
| **Amazon Associates** | 1-10% | affiliate-program.amazon.com |
| **Jasper AI** | 30% recurring | jasper.ai/affiliate |
| **Hostinger** | 60% per sale | hostinger.com/affiliates |
| **Semrush** | $200 per sale | semrush.com/affiliates |
| **Coursera** | 15-45% | coursera.org/affiliates |

Replace the affiliate links in `index.html` with your personal affiliate URLs.

---

## 📈 Realistic Income Timeline

| Month | Traffic | Income |
|-------|---------|--------|
| 1-2 | 0-500 visitors | $0-5 |
| 3-4 | 500-2,000 | $10-50 |
| 5-8 | 2,000-10,000 | $50-300 |
| 9-12 | 10,000-50,000 | $300-2,000 |
| Year 2 | 50,000+ | $2,000-10,000+ |

**Key to growth:** Publish 3-5 articles per week consistently.

---

## 🆘 Troubleshooting

**Site not showing up after upload?**
→ Check Settings → Pages → make sure "GitHub Actions" is selected

**API key not working?**
→ Make sure you copied the full key with no spaces

**Articles not loading?**
→ Check that articles.json is valid JSON (use jsonlint.com to validate)

---

## 📞 Need Help?

Ask Claude AI for help with any step! Just describe what's not working.
